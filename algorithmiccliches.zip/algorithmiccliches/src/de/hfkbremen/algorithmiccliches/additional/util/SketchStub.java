package de.hfkbremen.algorithmiccliches.additional.util;

import processing.core.PApplet;

public class SketchStub
        extends PApplet {

    public void settings() {
        size(1024, 768, P3D);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(new String[]{SketchStub.class.getName()});
    }
}
