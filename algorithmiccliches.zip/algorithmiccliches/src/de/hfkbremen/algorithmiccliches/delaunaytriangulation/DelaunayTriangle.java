package de.hfkbremen.algorithmiccliches.delaunaytriangulation;

public class DelaunayTriangle {

    public int[] p = new int[3];

}
