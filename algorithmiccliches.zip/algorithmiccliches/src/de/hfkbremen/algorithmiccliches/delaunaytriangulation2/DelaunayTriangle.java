package de.hfkbremen.algorithmiccliches.delaunaytriangulation2;

public class DelaunayTriangle {

    public int[] p = new int[3];

}
