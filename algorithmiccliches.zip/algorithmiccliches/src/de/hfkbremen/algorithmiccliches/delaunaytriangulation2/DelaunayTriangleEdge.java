package de.hfkbremen.algorithmiccliches.delaunaytriangulation2;

public class DelaunayTriangleEdge {

    public int[] p = new int[2];

    public DelaunayTriangleEdge() {
        p[0] = -1;
        p[1] = -1;
    }
}
