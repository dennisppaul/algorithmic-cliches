package de.hfkbremen.algorithmiccliches.octree;

import mathematik.Vector3f;

public interface OctreeEntity {

    Vector3f position();
}
