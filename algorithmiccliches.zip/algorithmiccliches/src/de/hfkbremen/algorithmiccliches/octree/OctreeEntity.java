package de.hfkbremen.algorithmiccliches.octree;

import processing.core.PVector;

public interface OctreeEntity {

    PVector position();
}
