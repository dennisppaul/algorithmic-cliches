package de.hfkbremen.algorithmiccliches;

public class AlgorithmicCliches {
}
