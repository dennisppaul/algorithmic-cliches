<#assign licenseFirst = "/*">
<#assign licensePrefix = " * Copyright (C) 2009 The Product, Patrick Kochlik + Dennis Paul">
<#assign licenseLast = " */">

<#if package?? && package != "">
package ${package};

</#if>
public interface ${name} {

}
